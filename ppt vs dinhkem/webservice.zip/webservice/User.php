<?php
     $connect = mysqli_connect("localhost", "root", "", "db_nhanvien" );
     mysqli_query($connect,"SET NAMES 'utf8'");

    
    //  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

     $ma = $_POST['id'];
    
    //  $ma = "10052121";
    //  $matkhau = "2";
    
     $query = "SELECT * FROM nguoidung WHERE ma = '$ma' ";
     //$data = mysqli_query($connect, $query); WHERE ma = '$ma' AND matkhau = '$pass'
    $response = mysqli_query($connect, $query);
    // if($data->num_row > 0){
    //     echo "thanh Cong";
    // }
    // else echo "Loi";
    //password_verify($matkhau, $row)
    

    $result = array();
    $result['login'] = array();

    if ( mysqli_num_rows($response) === 1)
    {
         $row = mysqli_fetch_assoc($response);
            
            $index["email"] = $row['email'];
            $index["name"] = $row['ten'];
            array_push($result["login"], $index);

            $result["success"] = "1";
            $result["messsge"] = "success";
            
            echo json_encode($result);
            mysqli_close($connect);
        
    }else{

        $result["success"] = "0" ;
        $result["messsge"] = "error";
        
        echo json_encode($result);
        mysqli_close($connect);
    }   
?>